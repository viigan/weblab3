package mk.ukim.finki.wp.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class WebProgrammingLab2024Application {
    public static void main(String[] args) {
        SpringApplication.run(WebProgrammingLab2024Application.class, args);
    }
}

